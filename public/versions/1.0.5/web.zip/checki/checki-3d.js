/* Editor de visuais: conserva as artes aprovadas. Rotacao multivistas com interpolacao. */
(()=>{'use strict';
const stage=document.getElementById('checki-stage');if(!stage)return;
stage.querySelector('canvas')?.remove();document.getElementById('checki-3d-fallback')?.remove();
const KEY='check-checki-visual-v1';
const paths={classico:Array.from({length:5},(_,i)=>`./checki/turnaround/view-${i}.webp`),natal:Array.from({length:5},(_,i)=>`./checki/turnaround/natal-${i}.webp`)};
let equipped='classico',preview='classico',angle=0,desired=0,drag=null,zoom=1,anim=0;
try{const v=localStorage.getItem(KEY);if(v in paths)equipped=preview=v}catch{}
const layer=document.createElement('div');layer.className='checki-viewer-layers';
const a=new Image(),b=new Image();[a,b].forEach(el=>{el.draggable=false;layer.appendChild(el)});stage.appendChild(layer);
Object.values(paths).flat().forEach(p=>{const im=new Image();im.src=p});
const controls=document.createElement('div');controls.className='checki-editor-controls';controls.innerHTML='<button type="button" id="checki-rotate-left" aria-label="Girar para a esquerda">↶</button><button type="button" id="checki-reset" aria-label="Voltar à frente">Frente</button><button type="button" id="checki-rotate-right" aria-label="Girar para a direita">↷</button><button type="button" id="checki-zoom-out" aria-label="Afastar">−</button><button type="button" id="checki-zoom-in" aria-label="Aproximar">+</button>';
stage.after(controls);
const apply=document.createElement('button');apply.type='button';apply.className='checki-apply-btn';apply.id='checki-equip';stage.parentNode.insertBefore(apply,controls.nextSibling);
function state(){document.querySelectorAll('[data-checki-variant]').forEach(btn=>{const v=btn.dataset.checkiVariant;btn.setAttribute('aria-pressed',String(preview===v));btn.textContent=(v==='natal'?'🎄 Natal':'🐾 Clássico')+(equipped===v?' · Equipado':'')});apply.disabled=equipped===preview;apply.textContent=equipped===preview?'✓ Visual equipado':'Equipar visual '+(preview==='natal'?'Natal':'Clássico');const status=document.getElementById('checki-variant-status');if(status)status.textContent=(preview==='natal'?'Natal':'Clássico')+(equipped===preview?' está equipado.':' em pré-visualização. Toque em Equipar para salvar.');}
function frame(){anim=0;angle+=(desired-angle)*.23;if(Math.abs(desired-angle)<.015)angle=desired;
// 8 intervalos, de frente ate costas e de volta. O crossfade evita saltos, mas nao cria geometria 3D.
let pos=((angle/45)%8+8)%8;const seq=[0,1,2,3,4,3,2,1];const idx=Math.floor(pos),mix=pos-idx;
a.src=paths[preview][seq[idx]];b.src=paths[preview][seq[(idx+1)%8]];a.style.opacity='1';b.style.opacity=String(mix);layer.style.transform=`scale(${zoom})`;
if(Math.abs(desired-angle)>.015)anim=requestAnimationFrame(frame);
}
function redraw(){if(!anim)anim=requestAnimationFrame(frame)}
document.querySelectorAll('[data-checki-variant]').forEach(btn=>btn.addEventListener('click',()=>{if(!(btn.dataset.checkiVariant in paths))return;preview=btn.dataset.checkiVariant;state();redraw()}));
apply.addEventListener('click',()=>{equipped=preview;try{localStorage.setItem(KEY,equipped)}catch{}state()});
stage.addEventListener('pointerdown',e=>{drag={id:e.pointerId,x:e.clientX};stage.setPointerCapture(e.pointerId)});
stage.addEventListener('pointermove',e=>{if(!drag||drag.id!==e.pointerId)return;desired+=(e.clientX-drag.x)*.55;drag.x=e.clientX;redraw()});
for(const ev of ['pointerup','pointercancel','lostpointercapture'])stage.addEventListener(ev,()=>drag=null);
stage.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){desired+=e.key==='ArrowLeft'?-22.5:22.5;redraw();e.preventDefault()}});
controls.querySelector('#checki-rotate-left').onclick=()=>{desired-=45;redraw()};controls.querySelector('#checki-rotate-right').onclick=()=>{desired+=45;redraw()};controls.querySelector('#checki-reset').onclick=()=>{desired=Math.round(desired/360)*360;redraw()};controls.querySelector('#checki-zoom-in').onclick=()=>{zoom=Math.min(1.6,zoom+.15);redraw()};controls.querySelector('#checki-zoom-out').onclick=()=>{zoom=Math.max(.75,zoom-.15);redraw()};
state();redraw();
})();
