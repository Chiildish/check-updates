/* Checki 3D — modelo procedural WebGL offline, sem bibliotecas externas. */
(function(){
'use strict';
var canvas=document.getElementById('checki-3d'),stage=document.getElementById('checki-stage');if(!canvas||!stage)return;
var gl=canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:false});
function fallback(){canvas.style.display='none';var el=document.getElementById('checki-3d-fallback');if(el)el.classList.remove('hide')}
if(!gl){fallback();return}
var vs='attribute vec3 p;attribute vec3 n;uniform mat4 mvp;uniform mat4 model;varying vec3 norm;varying vec3 pos;void main(){gl_Position=mvp*vec4(p,1.);norm=mat3(model)*n;pos=(model*vec4(p,1.)).xyz;}';
var fs='precision mediump float;varying vec3 norm;varying vec3 pos;uniform vec3 color;void main(){vec3 N=normalize(norm);vec3 L=normalize(vec3(-0.6,1.0,1.8));float diff=max(dot(N,L),0.);float rim=pow(1.-max(dot(N,vec3(0.,0.,1.)),0.),2.);vec3 c=color*(0.48+0.55*diff)+vec3(0.18)*rim;gl_FragColor=vec4(c,1.);}';
function shader(t,s){var x=gl.createShader(t);gl.shaderSource(x,s);gl.compileShader(x);if(!gl.getShaderParameter(x,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(x));return x}
var program;try{program=gl.createProgram();gl.attachShader(program,shader(gl.VERTEX_SHADER,vs));gl.attachShader(program,shader(gl.FRAGMENT_SHADER,fs));gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('link')}catch(e){fallback();return}
gl.useProgram(program);gl.enable(gl.DEPTH_TEST);gl.enable(gl.CULL_FACE);gl.clearColor(0,0,0,0);
var vertices=[],normals=[],indices=[],rings=18,segments=26;
for(var i=0;i<=rings;i++){var v=i*Math.PI/rings;for(var j=0;j<=segments;j++){var u=j*2*Math.PI/segments,x=Math.sin(v)*Math.cos(u),y=Math.cos(v),z=Math.sin(v)*Math.sin(u);vertices.push(x,y,z);normals.push(x,y,z)}}
for(var a=0;a<rings;a++)for(var b=0;b<segments;b++){var k=a*(segments+1)+b;indices.push(k,k+segments+1,k+1,k+1,k+segments+1,k+segments+2)}
function buffer(type,data){var b=gl.createBuffer();gl.bindBuffer(type,b);gl.bufferData(type,data,gl.STATIC_DRAW);return b}
var vb=buffer(gl.ARRAY_BUFFER,new Float32Array(vertices)),nb=buffer(gl.ARRAY_BUFFER,new Float32Array(normals)),ib=buffer(gl.ELEMENT_ARRAY_BUFFER,new Uint16Array(indices));
function attr(name,buf){var loc=gl.getAttribLocation(program,name);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,3,gl.FLOAT,false,0,0)}attr('p',vb);attr('n',nb);gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,ib);
var locMvp=gl.getUniformLocation(program,'mvp'),locModel=gl.getUniformLocation(program,'model'),locColor=gl.getUniformLocation(program,'color');
var pieces=[];function part(x,y,z,sx,sy,sz,color,rot){pieces.push({p:[x,y,z],s:[sx,sy,sz],c:color,r:rot||0})}
var red=[0.61,0.055,0.12],redLight=[0.79,0.14,0.22],cream=[1,.85,.69],pink=[.98,.58,.59],black=[.16,.055,.08],white=[1,.97,.9];
// Silhueta: orelhas triangulares aproximadas por volumes 3D, cauda e lenço.
part(0,-.64,0,.62,.77,.48,red);part(0,-.68,.39,.45,.58,.14,cream);
part(-.47,-1.15,.06,.27,.31,.32,red);part(.47,-1.15,.06,.27,.31,.32,red);
part(-.65,-.60,.04,.24,.43,.27,red);part(.65,-.60,.04,.24,.43,.27,red);
part(0,-.70,-.62,.43,.39,.43,redLight);part(0,-.72,-.91,.23,.22,.21,cream);
part(0,.58,0,.88,.78,.64,red);
part(-.63,1.19,.02,.38,.62,.26,red,.35);part(.63,1.19,.02,.38,.62,.26,red,-.35);
part(-.63,1.20,.25,.25,.42,.075,pink,.35);part(.63,1.20,.25,.25,.42,.075,pink,-.35);
part(0,.40,.52,.72,.48,.17,cream);part(0,.83,.50,.53,.36,.20,cream);
part(-.28,.68,.69,.07,.085,.055,black);part(.28,.68,.69,.07,.085,.055,black);
part(0,.46,.72,.10,.075,.07,black);part(-.14,.30,.69,.10,.035,.035,black);part(.14,.30,.69,.10,.035,.035,black);
part(-.47,.39,.58,.14,.07,.035,pink);part(.47,.39,.58,.14,.07,.035,pink);
part(0,-.06,.23,.58,.19,.45,redLight);part(0,-.26,.46,.26,.29,.09,red);part(0,-.46,.49,.14,.16,.10,redLight);
function mul(A,B){var R=new Float32Array(16);for(var c=0;c<4;c++)for(var r=0;r<4;r++)for(var k=0;k<4;k++)R[c*4+r]+=A[k*4+r]*B[c*4+k];return R}
function ident(){return new Float32Array([1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1])}
function trans(x,y,z){var m=ident();m[12]=x;m[13]=y;m[14]=z;return m}
function scale(x,y,z){var m=ident();m[0]=x;m[5]=y;m[10]=z;return m}
function ry(a){var m=ident(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[8]=s;m[2]=-s;m[10]=c;return m}
function rz(a){var m=ident(),c=Math.cos(a),s=Math.sin(a);m[0]=c;m[4]=-s;m[1]=s;m[5]=c;return m}
function perspective(aspect){var f=1/Math.tan(.55),near=.1,far=100,m=new Float32Array(16);m[0]=f/aspect;m[5]=f;m[10]=(far+near)/(near-far);m[11]=-1;m[14]=2*far*near/(near-far);return m}
var angle=-.25,last=null,dirty=true;
function render(){var rect=canvas.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2),w=Math.max(1,Math.floor(rect.width*dpr)),h=Math.max(1,Math.floor(rect.height*dpr));if(canvas.width!==w||canvas.height!==h){canvas.width=w;canvas.height=h}gl.viewport(0,0,w,h);gl.clear(gl.COLOR_BUFFER_BIT|gl.DEPTH_BUFFER_BIT);var view=mul(perspective(w/h),trans(0,-.05,-5.5)),turn=ry(angle);pieces.forEach(function(q){var model=mul(turn,mul(trans(q.p[0],q.p[1],q.p[2]),mul(rz(q.r),scale(q.s[0],q.s[1],q.s[2]))));gl.uniformMatrix4fv(locModel,false,model);gl.uniformMatrix4fv(locMvp,false,mul(view,model));gl.uniform3fv(locColor,q.c);gl.drawElements(gl.TRIANGLES,indices.length,gl.UNSIGNED_SHORT,0)});dirty=false}
function refresh(){dirty=true;requestAnimationFrame(function(){if(dirty)render()})}
stage.addEventListener('pointerdown',function(e){last=e.clientX;try{stage.setPointerCapture(e.pointerId)}catch(_){}});
stage.addEventListener('pointermove',function(e){if(last===null)return;angle+=(e.clientX-last)*.012;last=e.clientX;refresh()});
function end(){last=null}stage.addEventListener('pointerup',end);stage.addEventListener('pointercancel',end);
stage.addEventListener('keydown',function(e){if(e.key==='ArrowLeft'||e.key==='ArrowRight'){angle+=(e.key==='ArrowLeft'?-1:1)*.22;refresh();e.preventDefault()}});
if(typeof ResizeObserver!=='undefined')new ResizeObserver(refresh).observe(stage);
document.addEventListener('visibilitychange',function(){if(!document.hidden)refresh()});
// A aba Perfil começa oculta; redesenhar após abrir.
new MutationObserver(refresh).observe(document.getElementById('profile'),{attributes:true,attributeFilter:['class']});
refresh();
})();
