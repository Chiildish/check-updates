/* Visualizador de Checki: duas aparências aprovadas, seleção local e prévia multivistas. */
(function(){
 'use strict';
 const stage=document.getElementById('checki-stage');if(!stage)return;
 stage.querySelector('canvas')?.remove();document.getElementById('checki-3d-fallback')?.remove();
 const KEY='check-checki-visual-v1';
 const variants=['classico','natal'];
 const labels=['frente','três quartos','lateral','três quartos de costas','costas'];
 const sequence=[0,1,2,3,4,3,2,1];
 const paths={classico:Array.from({length:5},(_,i)=>'./checki/turnaround/view-'+i+'.webp'),natal:Array.from({length:5},(_,i)=>'./checki/turnaround/natal-'+i+'.webp')};
 let selected='classico';try{const stored=localStorage.getItem(KEY);if(variants.includes(stored))selected=stored}catch(e){}
 const img=document.createElement('img');img.draggable=false;img.style.cssText='width:100%;height:100%;object-fit:contain;display:block;user-select:none;pointer-events:none;border-radius:14px';stage.appendChild(img);
 Object.values(paths).flat().forEach(src=>{const preload=new Image();preload.src=src});
 let step=0,last=null;
 function draw(){const v=sequence[((step%sequence.length)+sequence.length)%sequence.length];img.src=paths[selected][v];img.alt='Checki '+(selected==='natal'?'de Natal':'Clássico')+', vista '+labels[v];}
 function update(){document.querySelectorAll('[data-checki-variant]').forEach(b=>{b.setAttribute('aria-pressed',String(b.dataset.checkiVariant===selected))});const status=document.getElementById('checki-variant-status');if(status)status.textContent='Visual '+(selected==='natal'?'Natal':'Clássico')+' selecionado. Sua escolha foi salva neste aparelho.';draw()}
 document.querySelectorAll('[data-checki-variant]').forEach(b=>b.addEventListener('click',()=>{selected=b.dataset.checkiVariant;try{localStorage.setItem(KEY,selected)}catch(e){}update()}));
 stage.addEventListener('pointerdown',e=>{last=e.clientX;stage.setPointerCapture?.(e.pointerId)});
 stage.addEventListener('pointermove',e=>{if(last===null)return;const delta=e.clientX-last;if(Math.abs(delta)>=12){step+=Math.trunc(delta/35)||Math.sign(delta);last=e.clientX;draw()}});
 stage.addEventListener('pointerup',()=>last=null);stage.addEventListener('pointercancel',()=>last=null);
 stage.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){step+=e.key==='ArrowLeft'?-1:1;draw();e.preventDefault()}});
 update();
})();
